const LarkCloud = require('./libs/larkcloud-mp-alpha.min.js');
const serviceId = 'af8581'; // 替换成你的 serviceId，可在后台「设置」页面获取
// 初始化
const larkcloud = new LarkCloud({ serviceId });
var dian
Page({
/**
* 页面的初始数据
*/
data: {
focus: false,
focus2: false,
focus3: false,
focus4: false,
focus5: false,
dian:0,
kcmc: "",
didian:"",
startzhou:"",
endzhou:"",
kcxx:"",
time:""
},
bindButtonTap: function () {
this.setData({
focus: true
})
},

bindKeyInput: function (e) {
this.setData({
kcmc: e.detail.value
})

},
bindButtonTap2: function () {
this.setData({
focus2: true
})
},
bindKeyInput2: function (e) {
this.setData({
didian: e.detail.value
})
},
bindButtonTap3: function () {
this.setData({
focus3: true
})
},
bindKeyInput3: function (e) {
this.setData({
time: e.detail.value
})
},
bindButtonTap4: function () {
this.setData({
focus4: true
})
},
bindKeyInput4: function (e) {
this.setData({
startzhou: e.detail.value
})
},
bindButtonTap5: function () {
this.setData({
focus5: true
})
},
bindKeyInput5: function (e) {
this.setData({
endzhou: e.detail.value
})
},
//用于保存修改的数据
save:function(){
 larkcloud.run('add_class_teacher', {//调用的云函数
idx:tt.getStorageSync('idxs'),//从本地存储获取课表位置
kcxx:this.data.kcmc,         //课程名称 
didian:this.data.didian,     //地点 
startzhou:this.data.startzhou,//开始周数
endzhou:this.data.endzhou,   //结束周数
time:this.data.time          //时间
}).then(data => {
       }); 
//数据库更新后返回更新后的记录并存入本地存储       
tt.setStorageSync('kcxx', this.data.kcmc + " "+ this.data.didian + " " + this.data.time + " "+ this.data.startzhou + "~" + this.data.endzhou + "周");
tt.navigateTo({
url: '/pages/subject/subject?dian=dian'
})
},
/**
* 生命周期函数--监听页面加载
*/
onLoad: function (options) {
var dian = options.idx;
},

/**
* 生命周期函数--监听页面初次渲染完成
*/
onReady: function () {

},

/**
* 生命周期函数--监听页面显示
*/
onShow: function () {

},

/**
* 生命周期函数--监听页面隐藏
*/
onHide: function () {

},

/**
* 生命周期函数--监听页面卸载
*/
onUnload: function () {

},

/**
* 页面相关事件处理函数--监听用户下拉动作
*/
onPullDownRefresh: function () {

},

/**
* 页面上拉触底事件的处理函数
*/
onReachBottom: function () {

},

/**
* 用户点击右上角分享
*/
onShareAppMessage: function () {

}
})